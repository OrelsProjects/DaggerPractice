package com.example.daggerpractice.di

import android.app.Application
import dagger.Module
import dagger.Provides

@Module
class AppModule {

    companion object {//Using a static method is more efficient, whenever possible. Probably less boilerplate code
        @Provides
        fun getString(): String {
            return "Provides Test"
        }
        @Suppress("SENSELESS_COMPARISON") //Because I have binded the Application in AppComponent, I can access it from my modules. If I didn't bind it, I would have gotten a null and returned false
        @Provides
        fun getApp(app: Application): Boolean{
            return app == null
        }
    }

}