package com.example.daggerpractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import dagger.android.support.DaggerAppCompatActivity
import javax.inject.Inject

class MainActivity : DaggerAppCompatActivity() {

    var string:String? = null
    @Inject set

    var bool:Boolean? = null
    @Inject set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(Companion.TAG, "onCreate: $string" )
        Log.d(TAG, "onCreate: $bool")

    }

    companion object {
        private const val TAG = "MainActivity"
    }
}